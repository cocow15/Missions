<template>
    <h1>About page</h1>
</template>
  